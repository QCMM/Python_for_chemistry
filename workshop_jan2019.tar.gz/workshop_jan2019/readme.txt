1. Either click on _build/html/index.html or run the command below.
   Now you have access to the latest API documentation.

$ open _build/html/index.html

2. Put chemtools-workshop_jan2019_concepcion.zip in yout Google Drive.
3. Copy and Past the URL below into a browser, and start running the commands one at a time.

https://colab.research.google.com/drive/1iQ3r_Cd1jx9w0vR-3ZSRM46OJ4cYrsWa

4. Go to the page below and try the examples (they need to be modified to work with the latest API).

https://chemtools.org/auto_examples/index.html



